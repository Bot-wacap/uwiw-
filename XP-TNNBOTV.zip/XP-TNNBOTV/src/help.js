const help = (prefix) => { 
	return `                 
┏━━━°❀ ❬ OWNER COMMAND ❭ ❀°━━━┓
┃
┏❉ *${prefix}bc*
┣❉ *${prefix}block*
┣❉ *${prefix}unblock*
┃
┣━━━°❀ ❬ STICKER COMMAND ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker*
┣➥ *${prefix}tsticker*
┃
┣━━━°❀ ❬ DONASI | BESTFREND ❭ ❀°━━━⊱
┃
┣➥ *${prefix}donasi*
┣➥ *${prefix}Support Bot UWBC*
┃
┣━━━°❀ ❬ UPDATE COMMAND ❭ ❀°━━━⊱

┣➥ *${prefix}pronlogo texts|texts*
┣➥ *${prefix}quotemaker contoh|bicit|random*
┣➥ *${prefix}text3d*
┣➥ *${prefix}ninjalogo*
┣➥ *${prefix}quotes*
┣➥ *${prefix}lirik*
┣➥ *${prefix}bucin*
┣➥ *${prefix}wolflogo*
┣➥ *${prefix}lionlogo*
┣➥ *${prefix}glitch teks|teks*
┣➥ *${prefix}artinama <nama>*
┣➥ *${prefix}apakah <saya gila>*
┣➥ *${prefix}truth*
┣➥ *${prefix}dare*
┣➥ *${prefix}map <daerah>*
┣➥ *${prefix}kbbi <anjing>*
┃
┣━━━━°❀🔗 ❬ COMMAND NSFW ❭ 🔗❀°━━━⊱
┃
┣➥ *${prefix}loli*
┣➥ *${prefix}waifu*
┣➥ *${prefix}randomhentai*
┣➥ *${prefix}nsfwtrap*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}nsfwneko*
┃Jika ingin mengaktifkan nya ketik
┃nsfw1 kalo mau di nonaktifkan nsfw0
┣━━━°❀ ❬ COMMAND DOWNLOADER ❭ ❀°━━⊱
┃
┣➥ *ytsearch* [search yt]
┣➥ *ytmp3* [link]
┣➥ *tiktok* [link]
┃
┣━━━━°❀ ❬ ADMIN ONLY ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setdesc <descripsi>
┣➥ *${prefix}add* [62xxx]
┣➥ *${prefix}kick* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}promote* [tag]
┣➥ *${prefix}unpromote* [tag]
┣➥ *${prefix}group* [buka/tutup]
┣➥ *${prefix}welcome* [1/0]
┣➥ *${prefix}nsfw* [1/0]
┣➥ *${prefix}simih* [1/0]
┣➥ *${prefix}groupinfo*
┃
┣━━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}bc* 
┣➥ *${prefix}leave*
┣➥ *${prefix}clearall*
┣➥ *${prefix}setprefix*
┣➥ *${prefix}clone* [tag]
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┃
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}listadmin*
┣➥ *${prefix}blocklist*
┣➥ *${prefix}simi*
┣➥ *${prefix}wait*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}url2img*
┣━━━━━° ❬ WARNING ❭ °━━━━━⊱
┃*BILA BOT TIDAK NGRESPON*
┃KETIK *${prefix}report [laporan]*
┣━━━━━━━━━━━━━━━━━━━━
┃ ${prefix}*Follow IG* ~_UW-BC~
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help
